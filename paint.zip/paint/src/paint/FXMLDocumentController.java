
package paint;

import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.control.ToggleButton;
import javafx.scene.shape.ArcType;
import javafx.scene.text.Font;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.StackPane;
/**
 *
 * @author Nikita
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private Canvas canvas;
    @FXML
    private ToggleButton brush;
    @FXML
    private ToggleButton drawText;
    @FXML
    private ImageView myImageView;
    @FXML
    private ColorPicker colorPicker;
    @FXML
    private ColorPicker colorp;
    private Stage stage;
    @FXML
    private TextField brushSize;
    @FXML
    private CheckBox eraser;
    @FXML
    private ColorPicker cpLine;
    @FXML
    private ColorPicker cpFill;
    @FXML
    double x1,x2,y1,y2;
    @FXML
    TextArea text;
    @FXML
    ImageView imageLine;
    @FXML
    ImageView imageCircle;
    @FXML
    ImageView imageRectangle;
    @FXML
    ImageView imageOvel;
    @FXML
    ImageView imageSqRect;
    @FXML
    ImageView imageStar;
    @FXML
    ImageView imageArc;
    @FXML
    ImageView imageTriangle;
    @FXML
    List<Canvas> list;
    @FXML
    int counter = -1;
    @FXML
    StackPane stackPane;
    @FXML
    MenuItem mItemRevert;
    @FXML
    MenuItem mItemRedo;
    @FXML
    ImageView Emoji1;
    @FXML
    ImageView Emoji2;
    @FXML
    ImageView Emoji3;
    @FXML
    ImageView Emoji4;
    @FXML
    ImageView Emoji5;
    @FXML
    ImageView Emoji6;
    @FXML
    ImageView Emoji7;
    @FXML
    ImageView Emoji8;
    @FXML
    ImageView Emoji9;
    @FXML
    ImageView Emoji10;
    @FXML
    ImageView Emoji11;
    @FXML
    ImageView Emoji12;
    @FXML
    ImageView Emoji13;
    @FXML
    ImageView Emoji14;
    @FXML
    ImageView Emoji15;
           
    
    
    
    @FXML
    public void initialize() {
    
        GraphicsContext g = canvas.getGraphicsContext2D();
        list = new ArrayList<>();
        canvas.setOnMouseDragged(e -> {
            double size = Double.parseDouble(brushSize.getText());
            double x = e.getX() - size / 2;
            double y = e.getY() - size / 2;

            if (eraser.isSelected()) {
                g.clearRect(x, y, size, size);
            } 
            else if(brush.isSelected()){
                g.setFill(colorPicker.getValue());
                g.fillRect(x, y, size, size); 
                //g.strokeRect(x, y, size, size);
              // g.lineTo(e.getX(), e.getY());
               //g.stroke();
            }
           
        });
        canvas.setOnMouseClicked(b -> {
            double size = Double.parseDouble(brushSize.getText());
            double x = b.getX() - size / 2;
            double y = b.getY() - size / 2;

            if (eraser.isSelected()) {
                g.clearRect(x, y, size, size);
            } 
            else if(brush.isSelected()){
                g.setFill(colorPicker.getValue());
                g.fillRect(x, y, size, size);
               }
           
            /*Canvas c = new Canvas(canvas.getWidth(), canvas.getHeight());
            c.setOnMousePressed(canvas.getOnMousePressed());
            c.setOnMouseDragged(canvas.getOnMouseDragged());
            c.setOnMouseClicked(canvas.getOnMouseClicked());
            try{
                if(list.contains(list.get(++counter))){
                    for (int i = list.size() - 1; i >= counter; i--) {
                        list.remove(i);
                    }
                }
            }
            catch(IndexOutOfBoundsException e){           
            }
            
            GraphicsContext gc;
            gc = canvas.getGraphicsContext2D();
            list.add(c);
            stackPane.getChildren().add(c);
            gc = c.getGraphicsContext2D();*/
        });   
   }
    
    @FXML
  public void bucket()
  {
    GraphicsContext gc = canvas.getGraphicsContext2D();
    gc.setFill(colorp.getValue());
    gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
   }      
  
    @FXML
   public void onSave() {
       //FileChooser fileChooser = new FileChooser();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save");
        fileChooser.getExtensionFilters().addAll(
        new FileChooser.ExtensionFilter("All Images", "*.*"),
        new FileChooser.ExtensionFilter("JPG", "*.jpg"),
        new FileChooser.ExtensionFilter("GIF", "*.gif"),
        new FileChooser.ExtensionFilter("BMP", "*.bmp"),
        new FileChooser.ExtensionFilter("PNG", "*.png")
        );
        try {
                Image snapshot = canvas.snapshot(null, null);
               Image ss = myImageView.getImage();
      //  group1.getChildren().addAll(snapshot, ss);
                File file = fileChooser.showSaveDialog(stage);
                fileChooser.setTitle("Save Image"); 
      
                if (file != null) {
                  
                    ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", file);
                   ImageIO.write(SwingFXUtils.fromFXImage(ss , null), "png", file);
                    
                }
            } catch (IOException e) {
            System.out.println("Failed to save image: " + e);
        }   
    }
           
    @FXML
    public void onSaveAsjpeg()
    {
        FileChooser fileChooser = new FileChooser();
        try {
            Image snapshot = canvas.snapshot(null, null);
            
            File file = fileChooser.showSaveDialog(stage);
            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "jpeg", new File(file+ ".jpeg"));
         } catch (IOException j) {
             System.out.println("Failed to save image: " + j);
        } 
    }

    @FXML
    public void onSaveAsGif()
    {
          FileChooser fileChooser = new FileChooser();
        try {
            Image snapshot = canvas.snapshot(null, null);
            File file = fileChooser.showSaveDialog(stage);
            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "gif", new File(file+ ".gif"));
         } catch (IOException j) {
            System.out.println("Failed to save image: " + j);
        }
    }
    @FXML
   public void onSaveAsPng() {
       FileChooser fileChooser = new FileChooser();
        try {
            Image snapshot = canvas.snapshot(null, null);
            File file = fileChooser.showSaveDialog(stage);
            ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", new File(file+ ".png"));
         } catch (IOException j) {
            System.out.println("Failed to save image: " + j);
        }
    }
   
    @FXML
   public void onOpen()
   {
           FileChooser fileChooser = new FileChooser();
            //Set extension filter
             fileChooser.getExtensionFilters().addAll(
             new FileChooser.ExtensionFilter("All Images", "*.*"),
             new FileChooser.ExtensionFilter("JPG", "*.jpg"),
             new FileChooser.ExtensionFilter("GIF", "*.gif"),
             new FileChooser.ExtensionFilter("BMP", "*.bmp"),
             new FileChooser.ExtensionFilter("PNG", "*.png")
            ); 
            //Show open file dialog
            File file = fileChooser.showOpenDialog(null);                     
            try {
                BufferedImage bufferedImage = ImageIO.read(file);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                 GraphicsContext gc = canvas.getGraphicsContext2D();
                gc.drawImage(image, 0, 0);
              // myImageView.setImage(image);
            } catch (IOException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
    } 
   
    @FXML
    public void onExit() {
        Platform.exit();
    }
    
    @FXML
    public void onNew()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, canvas.getHeight() ,canvas.getWidth() );
        myImageView.setImage(null);
    }
  
    @FXML
  public void drawRectangle(){
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        
        canvas.setOnMousePressed(b -> {
             x1 = b.getX();
             y1 = b.getY();
        });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
         
             double w = x2 -x1;
             double h = y2 - y1;
        
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
        
        if (w < 0) {
            w = -w;
            x1 = x1 - w;
        }
        if (h < 0) {
            h = -h;
            y1 =y1 - h;
        }
        gc.strokeRect(x1, y1, w, h);
        gc.fillRect(x1, y1, w, h);
        
        });
    }
    
    @FXML
    public void drawLine(){
      
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        canvas.setOnMousePressed(e -> {
             x1 = e.getX();
             y1 = e.getY();
       });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
             gc.setStroke(cpLine.getValue());
             gc.setLineWidth(size);
             gc.strokeLine(x1, y1, x2, y2);
            
        });
    }
    
    public void drawOval()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        
        canvas.setOnMousePressed(b -> {
             x1 = b.getX();
             y1 = b.getY();
        });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
         
             double w = x2 -x1;
             double h = y2 - y1;
        
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
        
        if (w < 0) {
            w = -w;
            x1 = x1 - w;
        }
        if (h < 0) {
            h = -h;
            y1 =y1 - h;
        }
        gc.strokeOval(x1, y1, w, h);
        gc.fillOval(x1, y1, w, h);
        });
    }
    
    public void drawTriangle()
    {
     GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        
        canvas.setOnMousePressed(b -> {
            gc.beginPath();
             x1 = b.getX();
             y1 = b.getY();
        });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
         
             double w = x2 -x1;
           //  double h = y2 - y1;
        
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
        
        gc.moveTo(x1 + (w / 2), y1);
        gc.lineTo(x2, y2);

        gc.moveTo(x1 + (w / 2), y1);
        gc.lineTo(x1, y2);

        gc.moveTo(x1, y2);
        gc.lineTo(x2, y2);

        gc.stroke();
        
        });
    }
    
    public void drawRoundRect()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        
        canvas.setOnMousePressed(b -> {
             x1 = b.getX();
             y1 = b.getY();
        });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
         
             double w = x2 -x1;
             double h = y2 - y1;
        
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
        
        if (w < 0) {
            w = -w;
            x1 = x1 - w;
        }
        if (h < 0) {
            h = -h;
            y1 = y1 - h;
        }
        gc.strokeRoundRect(x1, y1, w, h, 30, 30);
        gc.fillRoundRect(x1, y1, w, h, 30, 30);
        });
    }
    
    public void drawArc()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        
        canvas.setOnMousePressed(b -> {
             x1 = b.getX();
             y1 = b.getY();
        });
        
        canvas.setOnMouseReleased(e -> {
             x2 = e.getX();
             y2 = e.getY();
         
             double w = x2 -x1;
             double h = y2 - y1;
        
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
        
        if (w < 0) {
            w = -w;
            x1 = x1 - w;
        }
        if (h < 0) {
            h = -h;
            y1 = y1 - h;
        }
        gc.strokeArc(x1, y1, w, h,100 ,100, ArcType.CHORD);
        gc.fillArc(x1, y1, w, h, 100,100, ArcType.CHORD);
        });
    }
    public void drawStar() 
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        double size = Double.parseDouble(brushSize.getText());
        gc.setStroke(cpLine.getValue());
        gc.setFill(cpFill.getValue());
        gc.setLineWidth(size);
             double xpoints[] = {10, 85, 110, 135, 210, 160,170, 110, 50, 60};
             double ypoints[] = {85, 75, 10, 75, 85, 125,190, 150, 190, 125};
            // double xpoints[] = { 55, 67, 109, 73, 83, 55, 27, 37, 1, 43};
             //double ypoints[] = { 0, 36, 36, 54, 96, 72, 96, 54, 36, 36};
             gc.strokePolygon(xpoints, ypoints, xpoints.length);
    }
    public void drawText()
    {
        if(drawText.isSelected()){
        GraphicsContext gc = canvas.getGraphicsContext2D();
        canvas.setOnMousePressed(e ->{
            double size = Double.parseDouble(brushSize.getText());
                gc.setLineWidth(1);
                gc.setFont(Font.font(size));
                gc.setStroke(cpLine.getValue());
                gc.setFill(cpFill.getValue());
                gc.fillText(text.getText(), e.getX(), e.getY());
                gc.strokeText(text.getText(), e.getX(), e.getY());      
    });
    }
        else
            text.clear();
    }
    
    public void drawEmoji1()
    {    
        GraphicsContext gc = canvas.getGraphicsContext2D();
       //ImageView[] pic=new ImageView[]{Emoji1,Emoji2,Emoji3,Emoji4,Emoji5,Emoji6};
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji1.getImage(),e.getX(),e.getY());        
    });
    }
      
     public void drawEmoji2()
    {    
        GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji2.getImage(),e.getX(),e.getY());
    });
    }
    public void drwaEmoji3()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji3.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji4()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji4.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji5()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji5.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji6()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji6.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji7()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji7.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji8()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji8.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji9()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji9.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji10()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji10.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji11()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji11.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji12()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji12.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji13()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji13.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji14()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji14.getImage(),e.getX(),e.getY());
    }); 
    }
    public void drwaEmoji15()
    {
       GraphicsContext gc = canvas.getGraphicsContext2D();
            canvas.setOnMousePressed(e ->{
            gc.drawImage(Emoji15.getImage(),e.getX(),e.getY());
    }); 
    }
        
      Image line2 = new Image("paint/line2.png");
      Image line = new Image("paint/line.png");
      Image circle2 = new Image("paint/circle2.png");
      Image circle = new Image("paint/circle.png");
      Image rectangle2 = new Image("paint/rectangle2.png");
      Image rectangle = new Image("paint/rectangle.png");
      Image oval2 = new Image("paint/oval2.png");
      Image oval = new Image("paint/oval.png");
      Image sqRect2 = new Image("paint/polygon2.png");
      Image sqRect = new Image("paint/polygon.png");
      Image star2 = new Image("paint/star2.png");
      Image star = new Image("paint/star.png");
      Image arc2 = new Image("paint/Arc2.png");
      Image arc = new Image("paint/Arc.png");
      Image triangle2 = new Image("paint/triangle2.png");
      Image triangle = new Image("paint/triangle.png");
      
  public void mousePressed()
  {  
      if(imageLine.isPressed())
      imageLine.setImage(line2);
      else if(imageCircle.isPressed())
      imageCircle.setImage(circle2);
      else if(imageRectangle.isPressed())
      imageRectangle.setImage(rectangle2);
      else if(imageOvel.isPressed())
      imageOvel.setImage(oval2);
      else if(imageSqRect.isPressed())
      imageSqRect.setImage(sqRect2);
      else if(imageStar.isPressed())
      imageStar.setImage(star2);
      else if(imageArc.isPressed())
      imageArc.setImage(arc2);
      else if(imageTriangle.isPressed())
      imageTriangle.setImage(triangle2);
  }
    
    public void mouseEntered()
    {
        
      imageLine.setImage(line);
      imageCircle.setImage(circle);
      imageRectangle.setImage(rectangle);
      imageOvel.setImage(oval);
      imageSqRect.setImage(sqRect);
      imageStar.setImage(star);
      imageArc.setImage(arc);
      imageTriangle.setImage(triangle);      
      
    }
   public void redo(){
        mItemRedo.setOnAction(e -> {
            if(counter < list.size() - 1)
                stackPane.getChildren().add(list.get(++counter));
        });
    }

  public void undo(){
        mItemRevert.setOnAction(e -> {
            if(counter >= 0){
                stackPane.getChildren().remove(list.get(counter--));
            }
        });
    }   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
